
"use client";

import { useState } from "react";

export default function DashboardPanels() {
  const [showRules, setShowRules] = useState(false);

  return (
    <>
      <section className="mb-8 mt-6 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
        <div className="rounded-3xl border-[3px] border-[#111111] bg-white p-5 text-[#111111] shadow-[5px_5px_0_#111111]">
          <h2 className="text-xl font-black">Leaderboard</h2>

          <div className="mt-3 space-y-1 text-sm font-semibold">
            {[
              ["1. Riya", "320"],
              ["2. Kabir", "290"],
              ["3. Meera", "270"],
            ].map(([name, score]) => (
              <div
                key={name}
                className="flex justify-between gap-3 border-b-2 border-dashed border-[#111111]/30 py-1"
              >
                <span>{name}</span>
                <span>{score}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="rounded-3xl border-[3px] border-[#111111] bg-[#22d3ee] p-5 text-[#111111] shadow-[5px_5px_0_#111111]">
          <h2 className="text-xl font-black">Game History</h2>

          <div className="mt-3 space-y-1 text-sm font-semibold">
            {[
              ["Today", "210"],
              ["Yesterday", "320"],
              ["2 days ago", "150"],
            ].map(([day, score]) => (
              <div
                key={day}
                className="flex justify-between gap-3 border-b-2 border-dashed border-[#111111]/30 py-1"
              >
                <span>{day}</span>
                <span>{score}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="rounded-3xl border-[3px] border-[#111111] bg-[#ff6fb5] p-5 text-[#111111] shadow-[5px_5px_0_#111111] sm:col-span-2 lg:col-span-1">
          <h2 className="text-xl font-black">Help & Rules</h2>

          <p className="mt-2 text-sm font-medium leading-5">
            How lives, scoring and Boss questions work.
          </p>

          <button
            type="button"
            onClick={() => setShowRules(true)}
            className="mt-3 rounded-xl border-[3px] border-[#111111] bg-white px-4 py-2 text-sm font-black shadow-[2px_2px_0_#111111] transition hover:-translate-y-0.5"
          >
            Open rules
          </button>
        </div>
      </section>

      {showRules && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4"
          onClick={() => setShowRules(false)}
        >
          <section
            role="dialog"
            aria-modal="true"
            aria-labelledby="rules-title"
            className="w-full max-w-md rounded-2xl border-[3px] border-[#111111] bg-[#fff7e6] p-6 text-[#111111] shadow-[7px_7px_0_#111111]"
            onClick={(event) => event.stopPropagation()}
          >
            <div className="flex items-center justify-between gap-3">
              <h2 id="rules-title" className="text-2xl font-black">
                Game Rules
              </h2>

              <button
                type="button"
                onClick={() => setShowRules(false)}
                aria-label="Close rules"
                className="rounded-lg border-2 border-[#111111] bg-white px-3 py-1 font-black"
              >
                ✕
              </button>
            </div>

            <ul className="mt-4 list-disc space-y-2 pl-5 text-sm font-semibold leading-6">
              <li>Start each game with 3 lives.</li>
              <li>Read the passage before answering questions.</li>
              <li>Wrong answers cost points and one life.</li>
              <li>Skipping a question does not cost a life.</li>
              <li>Boss questions award more points but carry a bigger penalty.</li>
            </ul>

            <button
              type="button"
              onClick={() => setShowRules(false)}
              className="mt-5 rounded-xl border-[3px] border-[#111111] bg-[#b6ff00] px-5 py-2 font-black shadow-[3px_3px_0_#111111]"
            >
              Got it!
            </button>
          </section>
        </div>
      )}
    </>
  );
}
