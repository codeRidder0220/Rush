
"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { logout } from "../../actions/auth.js";

export default function Navbar({ username }) {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");

  async function handleLogout() {
    setLoading(true);
    setMessage("");

    try {
      const result = await logout();

      if (result.success) {
        router.replace("/login");
        router.refresh();
      } else {
        setMessage(result.message || "Logout failed");
        setLoading(false);
      }
    } catch {
      setMessage("Something went wrong. Please try again.");
      setLoading(false);
    }
  }

  return (
    <nav className="flex flex-wrap items-center justify-between gap-4">
      <div className="flex min-w-0 items-center gap-3">
        <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full border-[3px] border-[#111111] bg-[#ffd23f] text-2xl shadow-[2px_2px_0_#111111]">
          🦉
        </div>

        <div className="rounded-xl border-[3px] border-[#111111] bg-[#ffd23f] px-3 py-1 shadow-[4px_4px_0_#111111] sm:px-4">
          <h1 className="text-lg font-black leading-tight sm:text-2xl">
            Read & Remember
          </h1>
        </div>
      </div>

      <div className="flex items-center gap-2 sm:gap-3">
        <span className="max-w-32 truncate rounded-full border-[3px] border-[#111111] bg-white px-3 py-2 text-xs font-bold shadow-[2px_2px_0_#111111] sm:max-w-none sm:px-4 sm:text-sm">
          Hi, {username || "Player"}
        </span>

        <button
          type="button"
          onClick={handleLogout}
          disabled={loading}
          className="rounded-full border-[3px] border-[#111111] bg-[#ff6fb5] px-3 py-2 text-xs font-black shadow-[2px_2px_0_#111111] transition hover:-translate-y-0.5 disabled:opacity-60 sm:px-4 sm:text-sm"
        >
          {loading ? "Logging out..." : "Logout"}
        </button>
      </div>

      {message && (
        <p role="alert" className="w-full text-sm font-bold text-red-600">
          {message}
        </p>
      )}
    </nav>
  );
}
