
"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { login } from "../../actions/auth.js";

export default function LoginForm() {
  const router = useRouter();

  const [message, setMessage] = useState("");
  const [success, setSuccess] = useState(false);
  const [loading, setLoading] = useState(false);

  async function handleSubmit(event) {
    event.preventDefault();

    const form = event.currentTarget;
    const formData = new FormData(form);

    setMessage("");
    setSuccess(false);
    setLoading(true);

    try {
      const result = await login(formData);

      setMessage(result.message);
      setSuccess(result.success);

      if (result.success) {
        const destination =
          result.role === "admin" ? "/admin" : "/";

        router.replace(destination);
        router.refresh();
      }
    } catch {
      setMessage("Something went wrong. Please try again.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-5">
      <div>
        <label
          htmlFor="email"
          className="mb-2 block text-sm font-medium text-slate-200"
        >
          Email address
        </label>

        <input
          id="email"
          name="email"
          type="email"
          autoComplete="email"
          placeholder="you@example.com"
          required
          className="w-full rounded-xl border border-white/10 bg-[#0b1020] px-4 py-3.5 text-white outline-none transition placeholder:text-slate-600 focus:border-cyan-400 focus:ring-2 focus:ring-cyan-400/20"
        />
      </div>

      <div>
        <label
          htmlFor="password"
          className="mb-2 block text-sm font-medium text-slate-200"
        >
          Password
        </label>

        <input
          id="password"
          name="password"
          type="password"
          autoComplete="current-password"
          placeholder="Enter your password"
          required
          className="w-full rounded-xl border border-white/10 bg-[#0b1020] px-4 py-3.5 text-white outline-none transition placeholder:text-slate-600 focus:border-cyan-400 focus:ring-2 focus:ring-cyan-400/20"
        />
      </div>

      {message && (
        <p
          role="status"
          className={`rounded-xl px-4 py-3 text-sm ${success
              ? "border border-green-400/20 bg-green-400/10 text-green-300"
              : "border border-red-400/20 bg-red-400/10 text-red-300"
            }`}
        >
          {message}
        </p>
      )}

      <button
        type="submit"
        disabled={loading}
        className="w-full rounded-xl bg-linear-to-r from-cyan-400 to-purple-500 px-5 py-3.5 font-bold text-[#0b1020] shadow-lg shadow-cyan-500/10 transition hover:brightness-110 disabled:cursor-not-allowed disabled:opacity-60"
      >
        {loading ? "Logging in..." : "Login to RUSH →"}
      </button>

      <p className="pt-2 text-center text-sm text-slate-400">
        Don't have an account?{" "}
        <Link
          href="/signup"
          className="font-semibold text-cyan-300 transition hover:text-cyan-200"
        >
          Sign up
        </Link>
      </p>
    </form>
  );
}
