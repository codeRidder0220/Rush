
"use client";

import { useState } from "react";
import { signup } from "../../actions/auth.js";

export default function SignupForm() {
  const [message, setMessage] = useState("");
  const [success, setSuccess] = useState(false);
  const [loading, setLoading] = useState(false);

  async function handleSubmit(event) {
    event.preventDefault();

    setMessage("");
    setSuccess(false);
    setLoading(true);
    const form = event.currentTarget;
    const formData = new FormData(event.currentTarget);

    try {
      const result = await signup(formData);

      setMessage(result.message);
      setSuccess(result.success);

      if (result.success) {
        form.reset();
      }
    } catch (error) {
      setMessage("Something went wrong. Please try again.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-5">
      <div>
        <label htmlFor="username" className="mb-2 block text-sm font-medium text-slate-200">
          Username
        </label>
        <input
          id="username"
          name="username"
          type="text"
          minLength={3}
          maxLength={30}
          placeholder="Choose a username"
          autoComplete="username"
          required
          className="w-full rounded-xl border border-white/10 bg-[#0b1020] px-4 py-3.5 text-sm outline-none placeholder:text-slate-600 focus:border-purple-400"
        />
      </div>

      <div>
        <label htmlFor="email" className="mb-2 block text-sm font-medium text-slate-200">
          Email address
        </label>
        <input
          id="email"
          name="email"
          type="email"
          placeholder="you@example.com"
          autoComplete="email"
          required
          className="w-full rounded-xl border border-white/10 bg-[#0b1020] px-4 py-3.5 text-sm outline-none placeholder:text-slate-600 focus:border-purple-400"
        />
      </div>

      <div>
        <label htmlFor="password" className="mb-2 block text-sm font-medium text-slate-200">
          Password
        </label>
        <input
          id="password"
          name="password"
          type="password"
          minLength={8}
          placeholder="At least 8 characters"
          autoComplete="new-password"
          required
          className="w-full rounded-xl border border-white/10 bg-[#0b1020] px-4 py-3.5 text-sm outline-none placeholder:text-slate-600 focus:border-purple-400"
        />
      </div>

      {message && (
        <p
          role="status"
          className={`rounded-lg px-3 py-2 text-sm ${
            success
              ? "bg-lime-400/10 text-lime-300"
              : "bg-red-400/10 text-red-300"
          }`}
        >
          {message}
        </p>
      )}

      <button
        type="submit"
        disabled={loading}
        className="w-full rounded-xl bg-linear-to-r from-purple-500 to-violet-500 py-4 font-bold transition hover:from-purple-400 hover:to-violet-400 disabled:cursor-not-allowed disabled:opacity-60"
      >
        {loading ? "Creating account..." : "Create Account →"}
      </button>
    </form>
  );
}
