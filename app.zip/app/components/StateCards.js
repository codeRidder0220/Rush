
const stats = [
  { label: "Best Score", value: "320", color: "bg-[#ffd23f]" },
  { label: "Daily Streak", value: "5 days", color: "bg-[#ff7a00]" },
];

export default function StatsCards() {
  return (
    <section className="grid grid-cols-1 gap-4 sm:grid-cols-2">
      {stats.map((stat) => (
        <div
          key={stat.label}
          className={`flex min-h-24 items-center justify-between gap-3 rounded-3xl border-[3px] border-[#111111] ${stat.color} px-5 py-4 text-[#111111] shadow-[5px_5px_0_#111111] sm:px-6`}
        >
          <h2 className="text-base font-black sm:text-lg">
            {stat.label}
          </h2>

          <p className="text-3xl font-black tracking-tight sm:text-4xl">
            {stat.value}
          </p>
        </div>
      ))}
    </section>
  );
}
