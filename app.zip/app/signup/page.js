
import Link from "next/link";
import SignupForm from "../components/SignupForm";

export default function SignupPage() {
  return (
    <main className="min-h-screen bg-[#0b1020] p-4 text-white sm:p-8">
      <div className="mx-auto grid min-h-[85vh] max-w-6xl overflow-hidden rounded-3xl border border-white/10 bg-[#11172b] shadow-2xl lg:grid-cols-2">

        {/* LEFT SIDE — Illustration */}
        <section className="relative flex flex-col items-center justify-center overflow-hidden bg-linear-to-br from-purple-950 via-[#24134b] to-[#102c46] p-8 text-center sm:p-12">

          <div className="absolute -left-16 -top-16 h-52 w-52 rounded-full bg-purple-500/20 blur-3xl" />
          <div className="absolute -bottom-16 -right-12 h-56 w-56 rounded-full bg-cyan-400/20 blur-3xl" />

          <div className="relative z-10">
            <p className="mb-3 text-sm font-bold tracking-[0.3em] text-cyan-300">
              READ. REMEMBER. RUSH.
            </p>

            <h1 className="text-4xl font-black sm:text-5xl">
              Your brain,
              <span className="block text-orange-400">
                your arena!
              </span>
            </h1>

            {/* Temporary funny illustration */}
            <div className="mx-auto my-8 flex h-56 w-56 rotate-[-4deg] items-center justify-center rounded-[2.5rem] border border-white/15 bg-white/10 text-8xl shadow-xl backdrop-blur-sm transition-transform duration-300 hover:rotate-3 hover:scale-105 sm:h-64 sm:w-64">
              🤪
            </div>

            <p className="mx-auto max-w-sm text-sm leading-6 text-purple-100/80 sm:text-base">
              Think fast, remember everything,
              and prove your brain has superpowers.
            </p>

            <div className="mt-6 flex justify-center gap-3 text-xs font-bold">
              <span className="rounded-full bg-cyan-300/10 px-4 py-2 text-cyan-300">
                THINK FAST
              </span>
              <span className="rounded-full bg-orange-400/10 px-4 py-2 text-orange-300">
                HAVE FUN
              </span>
            </div>
          </div>
        </section>

        {/* RIGHT SIDE — Signup Form */}
        <section className="flex items-center justify-center p-6 sm:p-12 lg:p-14">
          <div className="w-full max-w-md">

            <Link
              href="/"
              className="text-sm font-semibold text-slate-400 transition hover:text-white"
            >
              ← Back to home
            </Link>

            <div className="mb-8 mt-8">
              <p className="mb-3 text-sm font-bold uppercase tracking-widest text-purple-400">
                Join the game
              </p>

              <h2 className="text-3xl font-black sm:text-4xl">
                Create account<span className="text-cyan-400">.</span>
              </h2>

              <p className="mt-3 text-sm leading-6 text-slate-400">
                Create your account and get ready to challenge your memory.
              </p>
            </div>

            <SignupForm/>

            <p className="mt-6 text-center text-sm text-slate-400">
              Already have an account?{" "}
              <Link
                href="/login"
                className="font-bold text-cyan-300 transition hover:text-cyan-200"
              >
                Log in
              </Link>
            </p>

          </div>
        </section>
      </div>
    </main>
  );
}
