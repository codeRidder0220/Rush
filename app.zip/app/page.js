
import Navbar from "./components/Navbar";
import StatsCards from "./components/StateCards";
import StartGame from "./components/StartGame";
import DashboardPanels from "./components/DashboardPanel";
import { redirect } from "next/navigation";
import { getCurrentUser } from "../lib/auth.js";

export default async function Home() {
  const user = await getCurrentUser();

  if (!user) {
    redirect("/login");
  }

  return (
    <main
      className="min-h-screen bg-[#fff7e6] px-4 py-5 text-[#111111] sm:px-6 lg:px-8"
      style={{
        backgroundImage:
          "radial-gradient(#11111120 1.5px, transparent 1.5px)",
        backgroundSize: "22px 22px",
      }}
    >
      <div className="mx-auto max-w-7xl">
        <Navbar username={user.username} />

        <section className="mt-6 grid grid-cols-1 items-stretch gap-5 lg:grid-cols-[1.3fr_1fr]">
          <StartGame />

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-1">
            <StatsCards />
          </div>
        </section>

        <DashboardPanels />
      </div>
    </main>
  );
}
