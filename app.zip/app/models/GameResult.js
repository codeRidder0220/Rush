
import mongoose from "mongoose";

const gameResultSchema = new mongoose.Schema(
  {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },

    content: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Content",
      required: true,
    },

    score: {
      type: Number,
      required: true,
      default: 0,
    },

    correctAnswers: {
      type: Number,
      default: 0,
    },

    wrongAnswers: {
      type: Number,
      default: 0,
    },

    livesRemaining: {
      type: Number,
      default: 4,
    },

    completionTime: {
      type: Number,
      required: true,
    },

    completed: {
      type: Boolean,
      default: false,
    },
  },
  { timestamps: true }
);

const GameResult = mongoose.models.GameResult || mongoose.model("GameResult", gameResultSchema);
  

export default GameResult;
