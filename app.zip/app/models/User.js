
import mongoose from "mongoose";

const userSchema = new mongoose.Schema(
  {
    username: {
      type: String,
      required: true,
      trim: true,
    },

    email: {
      type: String,
      required: true,
      unique: true,
      lowercase: true,
      trim: true,
    },

    passwordHash: {
      type: String,
      required: true,
    },

    role: {
      type: String,
      enum: ["user", "admin"], //role ko sirf user ya admin tak restrict karta hai.
      default: "user",
    },

    bestScore: {
      type: Number,
      default: 0,
    },

    dailyStreak: {
      type: Number,
      default: 0,
    },
  },
  { timestamps: true }
);

  
const User = mongoose.models.User || mongoose.model("User", userSchema);

export default User;
