
import LoginForm from "../components/LoginForm.js";

export default function LoginPage() {
  return (
    <main className="min-h-screen bg-[#0b1020] px-4 py-8 text-white sm:px-8 lg:px-12">
      <div className="mx-auto grid min-h-[85vh] max-w-6xl overflow-hidden rounded-3xl border border-white/10 bg-[#11172b] shadow-2xl shadow-purple-950/30 lg:grid-cols-2">

        {/* LEFT: Login Form */}
        <section className="flex items-center justify-center px-6 py-12 sm:px-12 lg:px-14">
          <div className="w-full max-w-md">
            <p className="mb-3 text-sm font-bold uppercase tracking-[0.3em] text-cyan-400">
              RUSH Arcade
            </p>

            <h1 className="text-4xl font-black tracking-tight sm:text-5xl">
              Welcome <span className="text-purple-400">back!</span>
            </h1>

            <p className="mt-3 text-slate-400">
              Ready to test your memory? Jump back into the game.
            </p>

            <div className="mt-8">
              <LoginForm />
            </div>
          </div>
        </section>

        {/* RIGHT: Illustration Panel */}
        <section className="relative hidden min-h-150 items-center justify-center overflow-hidden bg-linear-to-br from-[#25134b] via-[#40206b] to-[#101c3d] p-10 lg:flex">
          {/* Background glow effects */}
          <div className="absolute -right-16 -top-16 h-64 w-64 rounded-full bg-cyan-400/20 blur-3xl" />
          <div className="absolute -bottom-16 -left-10 h-72 w-72 rounded-full bg-orange-400/20 blur-3xl" />

          <div className="relative z-10 max-w-md text-center">
            <div className="mx-auto flex h-64 w-64 items-center justify-center rounded-[3rem] border border-white/20 bg-white/5 shadow-2xl shadow-purple-950/50 backdrop-blur-sm">
              <div className="text-center">
                <div className="text-8xl drop-shadow-[0_0_25px_rgba(34,211,238,0.4)]">
                  🧠
                </div>
                <div className="mt-5 flex justify-center gap-3 text-3xl">
                  <span className="animate-bounce">⚡</span>
                  <span className="animate-pulse">🎯</span>
                  <span className="animate-bounce">🚀</span>
                </div>
              </div>
            </div>

            <h2 className="mt-10 text-4xl font-black leading-tight">
              Your brain.
              <br />
              <span className="text-cyan-300">Your next high score.</span>
            </h2>

            <p className="mx-auto mt-4 max-w-sm leading-7 text-purple-100/80">
              Read fast, remember more, and beat your personal best.
              The next challenge is waiting for you.
            </p>

            <div className="mt-8 flex justify-center gap-2">
              <span className="h-2 w-8 rounded-full bg-cyan-300" />
              <span className="h-2 w-2 rounded-full bg-white/30" />
              <span className="h-2 w-2 rounded-full bg-white/30" />
            </div>
          </div>
        </section>

      </div>
    </main>
  );
}
